# nfl_viz
This app uses nfl_py_data package.
It uses pbp data to create visualizations on a streamlit app.
